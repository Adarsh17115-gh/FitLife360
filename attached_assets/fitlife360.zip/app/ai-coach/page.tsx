import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { db } from "@/lib/db"
import AIChatInterface from "@/components/ai-chat-interface"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageSquare, Utensils, Dumbbell, Activity } from "lucide-react"

export default async function AICoachPage() {
  const session = await getServerSession(authOptions)

  if (!session || !session.user) {
    redirect("/auth/signin")
  }

  const user = await db.user.findUnique({
    where: { id: session.user.id },
  })

  if (!user) {
    redirect("/auth/signin")
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-6">AI Health Coach</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <AIChatInterface user={user} />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Coach Features</CardTitle>
              <CardDescription>AI-powered health assistance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Personalized Guidance</h3>
                    <p className="text-sm text-muted-foreground">
                      Get tailored advice based on your family's health data
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Utensils className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Nutrition Planning</h3>
                    <p className="text-sm text-muted-foreground">Meal suggestions and dietary recommendations</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-purple-100 p-2 rounded-full">
                    <Dumbbell className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Workout Optimization</h3>
                    <p className="text-sm text-muted-foreground">Adjusts exercise plans based on progress and goals</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-amber-100 p-2 rounded-full">
                    <Activity className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Health Insights</h3>
                    <p className="text-sm text-muted-foreground">Analyzes trends and provides actionable insights</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>How to Use the AI Coach</CardTitle>
              <CardDescription>Get the most out of your virtual assistant</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="space-y-1">
                  <h3 className="font-medium">Ask Specific Questions</h3>
                  <p className="text-sm text-muted-foreground">
                    "How can I improve my sleep quality?" works better than "Help me sleep."
                  </p>
                </div>

                <div className="space-y-1">
                  <h3 className="font-medium">Provide Context</h3>
                  <p className="text-sm text-muted-foreground">
                    Include relevant details like "I'm training for a 5K" or "I have knee pain."
                  </p>
                </div>

                <div className="space-y-1">
                  <h3 className="font-medium">Follow Up</h3>
                  <p className="text-sm text-muted-foreground">
                    Ask for clarification or more details if you need them.
                  </p>
                </div>

                <div className="space-y-1">
                  <h3 className="font-medium">Give Feedback</h3>
                  <p className="text-sm text-muted-foreground">
                    Use the thumbs up/down to help improve future responses.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

