import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { db } from "@/lib/db"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { code } = await req.json()

    // Find the family with this invite code
    const family = await db.family.findFirst({
      where: { inviteCode: code },
    })

    if (!family) {
      return NextResponse.json({ message: "Invalid invite code" }, { status: 404 })
    }

    // Add the user to the family
    await db.user.update({
      where: { id: session.user.id },
      data: {
        familyId: family.id,
        role: "MEMBER", // Default role for joining members
      },
    })

    return NextResponse.json({ message: "Successfully joined family", familyId: family.id }, { status: 200 })
  } catch (error) {
    console.error("Error joining family:", error)
    return NextResponse.json({ message: "Error joining family" }, { status: 500 })
  }
}

