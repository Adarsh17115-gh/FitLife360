import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { db } from "@/lib/db"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { generateInviteCode } from "@/lib/utils"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { name } = await req.json()

    // Generate a unique invite code
    const inviteCode = generateInviteCode()

    // Create a new family
    const family = await db.family.create({
      data: {
        name,
        inviteCode,
        members: {
          connect: { id: session.user.id },
        },
      },
    })

    // Update the user to be an admin of this family
    await db.user.update({
      where: { id: session.user.id },
      data: {
        role: "ADMIN",
        familyId: family.id,
      },
    })

    return NextResponse.json({ message: "Family created successfully", id: family.id, inviteCode }, { status: 201 })
  } catch (error) {
    console.error("Error creating family:", error)
    return NextResponse.json({ message: "Error creating family" }, { status: 500 })
  }
}

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    // Get the user's family
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: {
        family: {
          include: {
            members: {
              select: {
                id: true,
                name: true,
                email: true,
                image: true,
                role: true,
                profile: true,
              },
            },
          },
        },
      },
    })

    if (!user?.family) {
      return NextResponse.json({ message: "No family found" }, { status: 404 })
    }

    return NextResponse.json(user.family)
  } catch (error) {
    console.error("Error fetching family:", error)
    return NextResponse.json({ message: "Error fetching family" }, { status: 500 })
  }
}

