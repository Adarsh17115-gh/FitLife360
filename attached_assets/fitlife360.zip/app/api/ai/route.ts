import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { db } from "@/lib/db"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { prompt } = await req.json()

    if (!prompt) {
      return NextResponse.json({ message: "Prompt is required" }, { status: 400 })
    }

    // Get user data to personalize the AI response
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      include: {
        profile: true,
        healthData: {
          orderBy: { date: "desc" },
          take: 7,
        },
        workouts: {
          orderBy: { date: "desc" },
          take: 5,
        },
        meals: {
          orderBy: { date: "desc" },
          take: 5,
          include: { foods: true },
        },
      },
    })

    // Create a system prompt with user context
    const systemPrompt = `
      You are an AI health coach for the FitLife 360 family fitness app. 
      Your name is Coach AI and you provide personalized fitness, nutrition, and health advice.
      
      User Information:
      - Name: ${user?.name || "User"}
      - Gender: ${user?.profile?.gender || "Unknown"}
      - Age: ${user?.profile?.dateOfBirth ? Math.floor((new Date().getTime() - new Date(user.profile.dateOfBirth).getTime()) / 3.15576e10) : "Unknown"} years
      - Height: ${user?.profile?.height || "Unknown"} cm
      - Weight: ${user?.profile?.weight || "Unknown"} kg
      - Fitness Goal: ${user?.profile?.fitnessGoal?.replace("-", " ") || "Unknown"}
      - Activity Level: ${user?.profile?.activityLevel?.replace("-", " ") || "Unknown"}
      - Dietary Preferences: ${user?.profile?.dietaryPreferences?.join(", ") || "None specified"}
      
      Recent Activity:
      - Workouts: ${user?.workouts?.length || 0} in the last week
      - Average Daily Steps: ${calculateAverageSteps(user?.healthData) || "Unknown"}
      
      Be friendly, motivational, and provide science-based advice tailored to the user's profile.
      Keep responses concise and actionable.
    `

    // Generate AI response
    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: prompt,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("AI generation error:", error)
    return NextResponse.json({ message: "Error generating AI response" }, { status: 500 })
  }
}

function calculateAverageSteps(healthData) {
  if (!healthData || healthData.length === 0) return null

  const stepsData = healthData.filter((data) => data.steps)
  if (stepsData.length === 0) return null

  const totalSteps = stepsData.reduce((sum, data) => sum + data.steps, 0)
  return Math.round(totalSteps / stepsData.length)
}

