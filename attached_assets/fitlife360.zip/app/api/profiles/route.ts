import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { db } from "@/lib/db"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const { dateOfBirth, height, weight, gender, fitnessGoal, activityLevel, dietaryPreferences, allergies, familyId } =
      await req.json()

    // Create or update profile
    const profile = await db.profile.upsert({
      where: { userId: session.user.id },
      update: {
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : undefined,
        height,
        weight,
        gender,
        fitnessGoal,
        activityLevel,
        dietaryPreferences,
        allergies,
      },
      create: {
        userId: session.user.id,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        height,
        weight,
        gender,
        fitnessGoal,
        activityLevel,
        dietaryPreferences,
        allergies,
      },
    })

    // Update user's family
    if (familyId) {
      await db.user.update({
        where: { id: session.user.id },
        data: { familyId },
      })
    }

    return NextResponse.json({ message: "Profile created successfully", profile }, { status: 201 })
  } catch (error) {
    console.error("Error creating profile:", error)
    return NextResponse.json({ message: "Error creating profile" }, { status: 500 })
  }
}

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    const profile = await db.profile.findUnique({
      where: { userId: session.user.id },
    })

    if (!profile) {
      return NextResponse.json({ message: "Profile not found" }, { status: 404 })
    }

    return NextResponse.json(profile)
  } catch (error) {
    console.error("Error fetching profile:", error)
    return NextResponse.json({ message: "Error fetching profile" }, { status: 500 })
  }
}

