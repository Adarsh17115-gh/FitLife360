import { getServerSession } from "next-auth"
import { redirect } from "next/navigation"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import WearableIntegration from "@/components/wearable-integration"
import { Shield, Smartphone, Globe } from "lucide-react"

export default async function SettingsPage() {
  const session = await getServerSession(authOptions)

  if (!session || !session.user) {
    redirect("/auth/signin")
  }

  return (
    <div className="container max-w-4xl py-10">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>

      <Tabs defaultValue="account" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        <TabsContent value="account" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>Manage your account details and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="p-2 border rounded-md flex-1 text-muted-foreground">{session.user.email}</div>
                    <Button variant="outline" size="sm">
                      Verify
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="p-2 border rounded-md flex-1 text-muted-foreground">••••••••••••</div>
                    <Button variant="outline" size="sm">
                      Change
                    </Button>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="font-medium mb-3">Danger Zone</h3>
                <div className="flex justify-between items-center p-3 bg-red-50 border border-red-200 rounded-md">
                  <div>
                    <h4 className="font-medium text-red-800">Delete Account</h4>
                    <p className="text-sm text-red-600">Permanently delete your account and all associated data</p>
                  </div>
                  <Button variant="destructive" size="sm">
                    Delete
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6 mt-6">
          <WearableIntegration />

          <Card>
            <CardHeader>
              <CardTitle>Mobile App Integration</CardTitle>
              <CardDescription>Connect with our mobile applications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-100 p-2 rounded-full">
                    <Smartphone className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">FitLife 360 Mobile App</h3>
                    <p className="text-sm text-muted-foreground">Sync data between web and mobile</p>
                  </div>
                </div>
                <div>
                  <Button variant="outline">Download App</Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="bg-gray-100 p-2 rounded-full">
                    <Globe className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Third-Party Apps</h3>
                    <p className="text-sm text-muted-foreground">Manage connections to other fitness apps</p>
                  </div>
                </div>
                <div>
                  <Button variant="outline">Manage</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Control how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Email Notifications</h3>

                <div className="space-y-3">
                  {[
                    { id: "workout-reminders", label: "Workout Reminders" },
                    { id: "meal-tracking", label: "Meal Tracking Reminders" },
                    { id: "challenge-updates", label: "Challenge Updates" },
                    { id: "family-activity", label: "Family Activity Summaries" },
                    { id: "weekly-report", label: "Weekly Health Reports" },
                  ].map((item) => (
                    <div key={item.id} className="flex items-center justify-between">
                      <Label htmlFor={item.id} className="flex-1">
                        {item.label}
                      </Label>
                      <Switch id={item.id} defaultChecked={true} />
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t">
                <h3 className="font-medium">Push Notifications</h3>

                <div className="space-y-3">
                  {[
                    { id: "push-workout", label: "Workout Reminders" },
                    { id: "push-meal", label: "Meal Tracking Reminders" },
                    { id: "push-challenge", label: "Challenge Updates" },
                    { id: "push-family", label: "Family Activity Alerts" },
                    { id: "push-goals", label: "Goal Achievements" },
                  ].map((item) => (
                    <div key={item.id} className="flex items-center justify-between">
                      <Label htmlFor={item.id} className="flex-1">
                        {item.label}
                      </Label>
                      <Switch id={item.id} defaultChecked={true} />
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Privacy Settings</CardTitle>
              <CardDescription>Control your data and privacy preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium">Data Sharing</h3>

                <div className="space-y-3">
                  {[
                    {
                      id: "share-family",
                      label: "Share data with family members",
                      description: "Allow your family to see your fitness and health data",
                    },
                    {
                      id: "share-ai",
                      label: "AI-powered recommendations",
                      description: "Allow AI to analyze your data for personalized recommendations",
                    },
                    {
                      id: "share-research",
                      label: "Contribute to research",
                      description: "Share anonymized data to help improve health and fitness research",
                    },
                  ].map((item) => (
                    <div key={item.id} className="flex items-start space-x-3">
                      <div className="pt-0.5">
                        <Switch id={item.id} defaultChecked={item.id !== "share-research"} />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor={item.id} className="font-medium">
                          {item.label}
                        </Label>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium">Download Your Data</h3>
                    <p className="text-sm text-muted-foreground">Get a copy of all your personal data</p>
                  </div>
                  <Button variant="outline">
                    <Shield className="h-4 w-4 mr-2" /> Export Data
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

