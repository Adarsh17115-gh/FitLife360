import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Activity, Users, Utensils, Dumbbell, Trophy } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-1/2 space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight">FitLife 360</h1>
              <p className="text-xl md:text-2xl opacity-90">
                The AI-powered family fitness app that brings your family's health journey together
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <Button size="lg" asChild>
                  <Link href="/dashboard">
                    Get Started <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-white/10">
                  <Link href="/about">Learn More</Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2">
              <img
                src="/placeholder.svg?height=400&width=500"
                alt="FitLife 360 App Preview"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Users className="h-10 w-10 text-blue-500" />}
              title="Multi-User Profiles"
              description="Custom fitness goals and age-based recommendations for every family member"
            />
            <FeatureCard
              icon={<Utensils className="h-10 w-10 text-green-500" />}
              title="AI-Powered Nutrition"
              description="Automated meal planning, macro tracking, and food recognition"
            />
            <FeatureCard
              icon={<Dumbbell className="h-10 w-10 text-orange-500" />}
              title="Personalized Workouts"
              description="AI-generated workouts with form correction and real-time analytics"
            />
            <FeatureCard
              icon={<Trophy className="h-10 w-10 text-yellow-500" />}
              title="Family Challenges"
              description="Gamified fitness challenges and family leaderboards"
            />
            <FeatureCard
              icon={<Activity className="h-10 w-10 text-purple-500" />}
              title="Health Analytics"
              description="Comprehensive health tracking and insights for the whole family"
            />
            <FeatureCard
              icon={<Users className="h-10 w-10 text-red-500" />}
              title="AI Health Coach"
              description="Personalized guidance and support from your AI assistant"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to transform your family's fitness journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of families who are getting healthier together with FitLife 360
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/dashboard">Get Started Today</Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 text-gray-300 mt-auto">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold text-white">FitLife 360</h3>
              <p>© 2025 FitLife 360. All rights reserved.</p>
            </div>
            <div className="flex gap-6">
              <Link href="/privacy" className="hover:text-white">
                Privacy
              </Link>
              <Link href="/terms" className="hover:text-white">
                Terms
              </Link>
              <Link href="/contact" className="hover:text-white">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <Card className="h-full transition-all hover:shadow-lg">
      <CardHeader>
        <div className="mb-2">{icon}</div>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-base">{description}</CardDescription>
      </CardContent>
      <CardFooter>
        <Button variant="ghost" className="mt-2" asChild>
          <Link href="/features">
            Learn more <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

