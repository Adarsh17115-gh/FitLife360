import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Activity, Utensils, Dumbbell, Trophy, MessageSquare, TrendingUp, Heart } from "lucide-react"
import Link from "next/link"
import FamilyProgress from "@/components/family-progress"
import NutritionTracker from "@/components/nutrition-tracker"
import WorkoutPlan from "@/components/workout-plan"
import HealthMetrics from "@/components/health-metrics"
import AICoach from "@/components/ai-coach"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">FitLife 360</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/dashboard" className="font-medium text-primary">
              Dashboard
            </Link>
            <Link href="/nutrition" className="font-medium text-muted-foreground hover:text-primary">
              Nutrition
            </Link>
            <Link href="/workouts" className="font-medium text-muted-foreground hover:text-primary">
              Workouts
            </Link>
            <Link href="/challenges" className="font-medium text-muted-foreground hover:text-primary">
              Challenges
            </Link>
            <Link href="/analytics" className="font-medium text-muted-foreground hover:text-primary">
              Analytics
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <MessageSquare className="h-5 w-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-8">
        <div className="flex flex-col gap-8">
          {/* Welcome Section */}
          <section className="flex flex-col md:flex-row gap-6 items-start">
            <Card className="w-full md:w-2/3">
              <CardHeader>
                <CardTitle>Welcome back, Johnson Family!</CardTitle>
                <CardDescription>Your family's fitness journey is on track. Here's your daily summary.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <StatCard
                    icon={<TrendingUp className="h-5 w-5 text-green-500" />}
                    title="Family Activity"
                    value="87%"
                    description="of daily goals completed"
                  />
                  <StatCard
                    icon={<Utensils className="h-5 w-5 text-blue-500" />}
                    title="Nutrition"
                    value="1,840"
                    description="calories consumed today"
                  />
                  <StatCard
                    icon={<Heart className="h-5 w-5 text-red-500" />}
                    title="Health Score"
                    value="92"
                    description="overall family health"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="w-full md:w-1/3">
              <CardHeader>
                <CardTitle>Today's Plan</CardTitle>
                <CardDescription>
                  {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 p-2 rounded-full">
                      <Dumbbell className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Family HIIT Workout</p>
                      <p className="text-sm text-muted-foreground">5:30 PM • 30 min</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="bg-green-100 p-2 rounded-full">
                      <Utensils className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Dinner: Protein Bowl</p>
                      <p className="text-sm text-muted-foreground">7:00 PM • 520 cal</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-100 p-2 rounded-full">
                      <Trophy className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Step Challenge</p>
                      <p className="text-sm text-muted-foreground">All day • 3,245/10,000</p>
                    </div>
                  </div>
                  <Button className="w-full mt-2">View Full Schedule</Button>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
              <TabsTrigger value="workouts">Workouts</TabsTrigger>
              <TabsTrigger value="health">Health</TabsTrigger>
              <TabsTrigger value="coach">AI Coach</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <FamilyProgress />
                <Card>
                  <CardHeader>
                    <CardTitle>Family Challenges</CardTitle>
                    <CardDescription>Active challenges and achievements</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="border rounded-lg p-4">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2">
                            <Trophy className="h-5 w-5 text-yellow-500" />
                            <h3 className="font-medium">10K Steps Challenge</h3>
                          </div>
                          <Badge>3 days left</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">Family progress: 65%</p>
                        <Progress value={65} className="h-2" />
                        <div className="flex justify-between mt-4">
                          <div className="flex -space-x-2">
                            <Avatar className="border-2 border-background h-8 w-8">
                              <AvatarFallback>M</AvatarFallback>
                            </Avatar>
                            <Avatar className="border-2 border-background h-8 w-8">
                              <AvatarFallback>D</AvatarFallback>
                            </Avatar>
                            <Avatar className="border-2 border-background h-8 w-8">
                              <AvatarFallback>S</AvatarFallback>
                            </Avatar>
                            <Avatar className="border-2 border-background h-8 w-8">
                              <AvatarFallback>E</AvatarFallback>
                            </Avatar>
                          </div>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </div>

                      <div className="border rounded-lg p-4">
                        <div className="flex justify-between items-center mb-2">
                          <div className="flex items-center gap-2">
                            <Utensils className="h-5 w-5 text-green-500" />
                            <h3 className="font-medium">Veggie Week</h3>
                          </div>
                          <Badge variant="outline" className="bg-green-100 text-green-800">
                            Completed
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">Family achievement unlocked!</p>
                        <div className="flex justify-between mt-4">
                          <div className="flex items-center gap-1">
                            <Trophy className="h-4 w-4 text-yellow-500" />
                            <span className="text-sm font-medium">+250 points</span>
                          </div>
                          <Button variant="outline" size="sm">
                            View Reward
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="nutrition" className="mt-6">
              <NutritionTracker />
            </TabsContent>

            <TabsContent value="workouts" className="mt-6">
              <WorkoutPlan />
            </TabsContent>

            <TabsContent value="health" className="mt-6">
              <HealthMetrics />
            </TabsContent>

            <TabsContent value="coach" className="mt-6">
              <AICoach />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

function StatCard({ icon, title, value, description }) {
  return (
    <div className="flex flex-col p-4 border rounded-lg">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
      </div>
      <div className="text-2xl font-bold">{value}</div>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}

