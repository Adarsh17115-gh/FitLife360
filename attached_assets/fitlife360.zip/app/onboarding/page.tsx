"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Activity, ArrowRight } from "lucide-react"

export default function Onboarding() {
  const { data: session } = useSession()
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  // Family setup
  const [setupType, setSetupType] = useState("create") // "create" or "join"
  const [familyName, setFamilyName] = useState("")
  const [familyCode, setFamilyCode] = useState("")

  // Profile setup
  const [profile, setProfile] = useState({
    dateOfBirth: "",
    height: "",
    weight: "",
    gender: "",
    fitnessGoal: "",
    activityLevel: "",
    dietaryPreferences: [],
    allergies: [],
  })

  const handleProfileChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }))
  }

  const handleDietaryPreferenceChange = (preference) => {
    setProfile((prev) => {
      const current = [...prev.dietaryPreferences]
      if (current.includes(preference)) {
        return { ...prev, dietaryPreferences: current.filter((p) => p !== preference) }
      } else {
        return { ...prev, dietaryPreferences: [...current, preference] }
      }
    })
  }

  const handleAllergyChange = (allergy) => {
    setProfile((prev) => {
      const current = [...prev.allergies]
      if (current.includes(allergy)) {
        return { ...prev, allergies: current.filter((a) => a !== allergy) }
      } else {
        return { ...prev, allergies: [...current, allergy] }
      }
    })
  }

  const handleNext = () => {
    setStep(step + 1)
  }

  const handleBack = () => {
    setStep(step - 1)
  }

  const handleSubmit = async () => {
    setIsLoading(true)
    setError("")

    try {
      // First handle family creation/joining
      let familyId

      if (setupType === "create") {
        // Create a new family
        const familyResponse = await fetch("/api/families", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: familyName }),
        })

        if (!familyResponse.ok) {
          throw new Error("Failed to create family")
        }

        const familyData = await familyResponse.json()
        familyId = familyData.id
      } else {
        // Join an existing family
        const joinResponse = await fetch(`/api/families/join`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ code: familyCode }),
        })

        if (!joinResponse.ok) {
          throw new Error("Failed to join family. Invalid code.")
        }

        const joinData = await joinResponse.json()
        familyId = joinData.familyId
      }

      // Then create the user profile
      const profileResponse = await fetch("/api/profiles", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...profile,
          familyId,
          dateOfBirth: new Date(profile.dateOfBirth).toISOString(),
          height: Number.parseFloat(profile.height),
          weight: Number.parseFloat(profile.weight),
        }),
      })

      if (!profileResponse.ok) {
        throw new Error("Failed to create profile")
      }

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      setError(error.message || "An error occurred during onboarding")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-r from-blue-600 to-purple-600 p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Activity className="h-10 w-10 text-blue-600" />
          </div>
          <CardTitle className="text-2xl">Welcome to FitLife 360</CardTitle>
          <CardDescription>
            {step === 1 && "Let's set up your family account"}
            {step === 2 && "Tell us about yourself"}
            {step === 3 && "Almost done! Set your fitness preferences"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {step === 1 && (
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Family Setup</h3>
                <RadioGroup value={setupType} onValueChange={setSetupType} className="space-y-3">
                  <div className="flex items-start space-x-3 space-y-0">
                    <RadioGroupItem value="create" id="create" />
                    <div className="flex flex-col">
                      <Label htmlFor="create" className="font-medium">
                        Create a new family
                      </Label>
                      <p className="text-sm text-muted-foreground">Start a new family group that others can join</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 space-y-0">
                    <RadioGroupItem value="join" id="join" />
                    <div className="flex flex-col">
                      <Label htmlFor="join" className="font-medium">
                        Join an existing family
                      </Label>
                      <p className="text-sm text-muted-foreground">Join a family using an invite code</p>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              {setupType === "create" ? (
                <div className="space-y-2">
                  <Label htmlFor="familyName">Family Name</Label>
                  <Input
                    id="familyName"
                    placeholder="e.g., The Johnsons"
                    value={familyName}
                    onChange={(e) => setFamilyName(e.target.value)}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="familyCode">Family Invite Code</Label>
                  <Input
                    id="familyCode"
                    placeholder="Enter the 6-digit code"
                    value={familyCode}
                    onChange={(e) => setFamilyCode(e.target.value)}
                  />
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={profile.dateOfBirth}
                    onChange={(e) => handleProfileChange("dateOfBirth", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={profile.gender} onValueChange={(value) => handleProfileChange("gender", value)}>
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="e.g., 175"
                    value={profile.height}
                    onChange={(e) => handleProfileChange("height", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="e.g., 70"
                    value={profile.weight}
                    onChange={(e) => handleProfileChange("weight", e.target.value)}
                  />
                </div>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="fitnessGoal">Fitness Goal</Label>
                <Select
                  value={profile.fitnessGoal}
                  onValueChange={(value) => handleProfileChange("fitnessGoal", value)}
                >
                  <SelectTrigger id="fitnessGoal">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lose-weight">Lose Weight</SelectItem>
                    <SelectItem value="build-muscle">Build Muscle</SelectItem>
                    <SelectItem value="improve-fitness">Improve Fitness</SelectItem>
                    <SelectItem value="maintain">Maintain Current Fitness</SelectItem>
                    <SelectItem value="family-activity">Family Activity</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="activityLevel">Activity Level</Label>
                <Select
                  value={profile.activityLevel}
                  onValueChange={(value) => handleProfileChange("activityLevel", value)}
                >
                  <SelectTrigger id="activityLevel">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                    <SelectItem value="light">Lightly active (light exercise 1-3 days/week)</SelectItem>
                    <SelectItem value="moderate">Moderately active (moderate exercise 3-5 days/week)</SelectItem>
                    <SelectItem value="active">Very active (hard exercise 6-7 days/week)</SelectItem>
                    <SelectItem value="very-active">Extra active (very hard exercise & physical job)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Dietary Preferences</Label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    "Vegetarian",
                    "Vegan",
                    "Gluten-Free",
                    "Dairy-Free",
                    "Keto",
                    "Paleo",
                    "Low-Carb",
                    "Mediterranean",
                  ].map((preference) => (
                    <div key={preference} className="flex items-center space-x-2">
                      <Checkbox
                        id={preference.toLowerCase()}
                        checked={profile.dietaryPreferences.includes(preference.toLowerCase())}
                        onCheckedChange={() => handleDietaryPreferenceChange(preference.toLowerCase())}
                      />
                      <label
                        htmlFor={preference.toLowerCase()}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {preference}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Allergies or Restrictions</Label>
                <div className="grid grid-cols-2 gap-2">
                  {["Nuts", "Dairy", "Eggs", "Soy", "Wheat", "Shellfish", "Fish"].map((allergy) => (
                    <div key={allergy} className="flex items-center space-x-2">
                      <Checkbox
                        id={`allergy-${allergy.toLowerCase()}`}
                        checked={profile.allergies.includes(allergy.toLowerCase())}
                        onCheckedChange={() => handleAllergyChange(allergy.toLowerCase())}
                      />
                      <label
                        htmlFor={`allergy-${allergy.toLowerCase()}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {allergy}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {error && <p className="mt-4 text-sm text-red-500">{error}</p>}
        </CardContent>
        <CardFooter className="flex justify-between">
          {step > 1 ? (
            <Button variant="outline" onClick={handleBack} disabled={isLoading}>
              Back
            </Button>
          ) : (
            <div></div>
          )}

          {step < 3 ? (
            <Button onClick={handleNext} disabled={isLoading}>
              Next <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? "Completing Setup..." : "Complete Setup"}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}

