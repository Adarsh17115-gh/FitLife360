"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChartContainer } from "@/components/ui/chart"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from "recharts"
import { Heart, Activity, Droplet, Moon, Scale, Plus } from "lucide-react"
import { useState } from "react"

const familyMembers = [
  { id: 1, name: "David", role: "Dad", avatar: "D", color: "#4f46e5" },
  { id: 2, name: "Maria", role: "Mom", avatar: "M", color: "#ec4899" },
  { id: 3, name: "Sam", role: "Son", avatar: "S", color: "#10b981" },
  { id: 4, name: "Emma", role: "Daughter", avatar: "E", color: "#f59e0b" },
]

const heartRateData = [
  { day: "Mon", David: 72, Maria: 68, Sam: 82, Emma: 78 },
  { day: "Tue", David: 75, Maria: 70, Sam: 80, Emma: 76 },
  { day: "Wed", David: 71, Maria: 69, Sam: 83, Emma: 79 },
  { day: "Thu", David: 73, Maria: 67, Sam: 81, Emma: 77 },
  { day: "Fri", David: 70, Maria: 66, Sam: 79, Emma: 75 },
  { day: "Sat", David: 68, Maria: 65, Sam: 78, Emma: 74 },
  { day: "Sun", David: 69, Maria: 67, Sam: 80, Emma: 76 },
]

const sleepData = [
  { day: "Mon", David: 7.2, Maria: 6.8, Sam: 8.5, Emma: 8.2 },
  { day: "Tue", David: 7.5, Maria: 7.0, Sam: 8.3, Emma: 8.0 },
  { day: "Wed", David: 6.8, Maria: 6.5, Sam: 8.7, Emma: 8.4 },
  { day: "Thu", David: 7.0, Maria: 6.7, Sam: 8.2, Emma: 8.1 },
  { day: "Fri", David: 7.3, Maria: 7.1, Sam: 8.4, Emma: 8.3 },
  { day: "Sat", David: 7.8, Maria: 7.5, Sam: 9.0, Emma: 8.7 },
  { day: "Sun", David: 7.6, Maria: 7.2, Sam: 8.8, Emma: 8.5 },
]

const stepsData = [
  { day: "Mon", David: 8500, Maria: 7200, Sam: 6500, Emma: 5800 },
  { day: "Tue", David: 9200, Maria: 7800, Sam: 7000, Emma: 6200 },
  { day: "Wed", David: 7800, Maria: 6900, Sam: 5800, Emma: 5500 },
  { day: "Thu", David: 8300, Maria: 7500, Sam: 6700, Emma: 6000 },
  { day: "Fri", David: 9500, Maria: 8200, Sam: 7200, Emma: 6500 },
  { day: "Sat", David: 10200, Maria: 9000, Sam: 8500, Emma: 7800 },
  { day: "Sun", David: 7500, Maria: 6800, Sam: 6000, Emma: 5500 },
]

const healthMetrics = [
  {
    id: "heart-rate",
    title: "Resting Heart Rate",
    icon: <Heart className="h-5 w-5 text-red-500" />,
    data: [
      { member: "David", value: "72 bpm", trend: "stable" },
      { member: "Maria", value: "68 bpm", trend: "improving" },
      { member: "Sam", value: "82 bpm", trend: "stable" },
      { member: "Emma", value: "78 bpm", trend: "stable" },
    ],
  },
  {
    id: "sleep",
    title: "Sleep Duration",
    icon: <Moon className="h-5 w-5 text-purple-500" />,
    data: [
      { member: "David", value: "7.3 hrs", trend: "improving" },
      { member: "Maria", value: "6.9 hrs", trend: "needs improvement" },
      { member: "Sam", value: "8.5 hrs", trend: "excellent" },
      { member: "Emma", value: "8.2 hrs", trend: "excellent" },
    ],
  },
  {
    id: "steps",
    title: "Daily Steps",
    icon: <Activity className="h-5 w-5 text-blue-500" />,
    data: [
      { member: "David", value: "8,750", trend: "on target" },
      { member: "Maria", value: "7,650", trend: "on target" },
      { member: "Sam", value: "6,820", trend: "below target" },
      { member: "Emma", value: "6,150", trend: "below target" },
    ],
  },
  {
    id: "hydration",
    title: "Hydration",
    icon: <Droplet className="h-5 w-5 text-cyan-500" />,
    data: [
      { member: "David", value: "2.4 L", trend: "on target" },
      { member: "Maria", value: "2.1 L", trend: "on target" },
      { member: "Sam", value: "1.6 L", trend: "needs improvement" },
      { member: "Emma", value: "1.4 L", trend: "needs improvement" },
    ],
  },
  {
    id: "weight",
    title: "Weight",
    icon: <Scale className="h-5 w-5 text-green-500" />,
    data: [
      { member: "David", value: "182 lbs", trend: "stable" },
      { member: "Maria", value: "145 lbs", trend: "improving" },
      { member: "Sam", value: "110 lbs", trend: "growing" },
      { member: "Emma", value: "85 lbs", trend: "growing" },
    ],
  },
]

export default function HealthMetrics() {
  const [selectedMember, setSelectedMember] = useState("all")
  const [selectedMetric, setSelectedMetric] = useState("heart-rate")

  const getChartData = () => {
    switch (selectedMetric) {
      case "heart-rate":
        return heartRateData
      case "sleep":
        return sleepData
      case "steps":
        return stepsData
      default:
        return heartRateData
    }
  }

  const getYAxisLabel = () => {
    switch (selectedMetric) {
      case "heart-rate":
        return "BPM"
      case "sleep":
        return "Hours"
      case "steps":
        return "Steps"
      default:
        return ""
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Health Trends</CardTitle>
              <CardDescription>Track your family's health metrics over time</CardDescription>
            </div>
            <div className="flex gap-2">
              <Tabs value={selectedMetric} onValueChange={setSelectedMetric} className="w-[300px]">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="heart-rate">Heart Rate</TabsTrigger>
                  <TabsTrigger value="sleep">Sleep</TabsTrigger>
                  <TabsTrigger value="steps">Steps</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ChartContainer>
                <LineChart data={getChartData()} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="day" />
                  <YAxis label={{ value: getYAxisLabel(), angle: -90, position: "insideLeft" }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  {selectedMember === "all" ? (
                    familyMembers.map((member) => (
                      <Line
                        key={member.id}
                        type="monotone"
                        dataKey={member.name}
                        stroke={member.color}
                        strokeWidth={2}
                        dot={{ r: 4 }}
                        activeDot={{ r: 6 }}
                      />
                    ))
                  ) : (
                    <Line
                      type="monotone"
                      dataKey={selectedMember}
                      stroke={familyMembers.find((m) => m.name === selectedMember)?.color || "#4f46e5"}
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  )}
                </LineChart>
              </ChartContainer>
            </ResponsiveContainer>
          </div>

          <div className="flex justify-center mt-4 gap-2">
            <Button
              variant={selectedMember === "all" ? "default" : "outline"}
              onClick={() => setSelectedMember("all")}
              className="px-3"
            >
              All
            </Button>
            {familyMembers.map((member) => (
              <Button
                key={member.id}
                variant={selectedMember === member.name ? "default" : "outline"}
                onClick={() => setSelectedMember(member.name)}
                className="px-3"
                style={{
                  backgroundColor: selectedMember === member.name ? member.color : "transparent",
                  borderColor: member.color,
                  color: selectedMember === member.name ? "white" : member.color,
                }}
              >
                {member.name}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Health Insights</CardTitle>
            <CardDescription>AI-powered health recommendations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border rounded-lg p-4 bg-blue-50">
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <Droplet className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Hydration Alert</h3>
                    <p className="text-sm mt-1">
                      Sam and Emma are below their hydration targets. Encourage more water intake during activities.
                    </p>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4 bg-purple-50">
                <div className="flex items-start gap-3">
                  <div className="bg-purple-100 p-2 rounded-full">
                    <Moon className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Sleep Improvement</h3>
                    <p className="text-sm mt-1">
                      Maria's sleep duration is below recommended levels. Consider an earlier bedtime routine.
                    </p>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4 bg-green-50">
                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Activity className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-medium">Activity Milestone</h3>
                    <p className="text-sm mt-1">
                      David has maintained consistent activity levels for 2 weeks! Great progress.
                    </p>
                  </div>
                </div>
              </div>

              <Button variant="outline" className="w-full">
                View All Insights
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Health Metrics</CardTitle>
            <CardDescription>Current family health status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {healthMetrics.map((metric) => (
                <div key={metric.id} className="border rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    {metric.icon}
                    <h3 className="font-medium">{metric.title}</h3>
                  </div>
                  <div className="space-y-2 mt-3">
                    {metric.data.map((item, index) => (
                      <div key={index} className="flex justify-between items-center text-sm">
                        <span>{item.member}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{item.value}</span>
                          <span
                            className={`text-xs px-2 py-0.5 rounded-full ${
                              item.trend === "improving" || item.trend === "excellent"
                                ? "bg-green-100 text-green-800"
                                : item.trend === "needs improvement"
                                  ? "bg-amber-100 text-amber-800"
                                  : "bg-blue-100 text-blue-800"
                            }`}
                          >
                            {item.trend}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              <Button variant="outline" className="w-full flex items-center justify-center">
                <Plus className="h-4 w-4 mr-2" /> Add Health Metric
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) {
    return null
  }

  return (
    <div className="bg-white p-3 border rounded-md shadow-sm">
      <p className="font-medium">{label}</p>
      {payload.map((entry, index) => (
        <div key={index} className="flex items-center gap-2 text-sm">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
          <span>
            {entry.name}: {entry.value}
          </span>
        </div>
      ))}
    </div>
  )
}

