"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { calculateBMI, calculateCalorieNeeds } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

export default function ProfileForm({ user, profile }) {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("personal")

  const [formData, setFormData] = useState({
    name: user?.name || "",
    dateOfBirth: profile?.dateOfBirth ? new Date(profile.dateOfBirth).toISOString().split("T")[0] : "",
    height: profile?.height?.toString() || "",
    weight: profile?.weight?.toString() || "",
    gender: profile?.gender || "",
    fitnessGoal: profile?.fitnessGoal || "",
    activityLevel: profile?.activityLevel || "",
    dietaryPreferences: profile?.dietaryPreferences || [],
    allergies: profile?.allergies || [],
  })

  const [stats, setStats] = useState({
    bmi: 0,
    calorieNeeds: 0,
  })

  useEffect(() => {
    if (formData.weight && formData.height) {
      const bmi = calculateBMI(Number.parseFloat(formData.weight), Number.parseFloat(formData.height))
      setStats((prev) => ({ ...prev, bmi }))
    }

    if (formData.weight && formData.height && formData.dateOfBirth && formData.gender && formData.activityLevel) {
      const age = new Date().getFullYear() - new Date(formData.dateOfBirth).getFullYear()
      const calories = calculateCalorieNeeds(
        Number.parseFloat(formData.weight),
        Number.parseFloat(formData.height),
        age,
        formData.gender,
        formData.activityLevel,
      )
      setStats((prev) => ({ ...prev, calorieNeeds: calories }))
    }
  }, [formData.weight, formData.height, formData.dateOfBirth, formData.gender, formData.activityLevel])

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleDietaryPreferenceChange = (preference) => {
    setFormData((prev) => {
      const current = [...prev.dietaryPreferences]
      if (current.includes(preference)) {
        return { ...prev, dietaryPreferences: current.filter((p) => p !== preference) }
      } else {
        return { ...prev, dietaryPreferences: [...current, preference] }
      }
    })
  }

  const handleAllergyChange = (allergy) => {
    setFormData((prev) => {
      const current = [...prev.allergies]
      if (current.includes(allergy)) {
        return { ...prev, allergies: current.filter((a) => a !== allergy) }
      } else {
        return { ...prev, allergies: [...current, allergy] }
      }
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Update user name
      if (formData.name !== user.name) {
        await fetch("/api/users", {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ name: formData.name }),
        })
      }

      // Update profile
      const profileResponse = await fetch("/api/profiles", {
        method: "POST", // Using upsert in the API
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          dateOfBirth: formData.dateOfBirth,
          height: Number.parseFloat(formData.height),
          weight: Number.parseFloat(formData.weight),
          gender: formData.gender,
          fitnessGoal: formData.fitnessGoal,
          activityLevel: formData.activityLevel,
          dietaryPreferences: formData.dietaryPreferences,
          allergies: formData.allergies,
        }),
      })

      if (!profileResponse.ok) {
        throw new Error("Failed to update profile")
      }

      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      })

      router.refresh()
    } catch (error) {
      toast({
        title: "Error",
        description: error.message || "An error occurred while updating your profile.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={user?.image || ""} alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>Update your personal information and preferences</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="personal">Personal</TabsTrigger>
              <TabsTrigger value="fitness">Fitness</TabsTrigger>
              <TabsTrigger value="diet">Diet</TabsTrigger>
            </TabsList>

            <TabsContent value="personal" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" value={formData.name} onChange={(e) => handleChange("name", e.target.value)} />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleChange("dateOfBirth", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleChange("gender", value)}>
                    <SelectTrigger id="gender">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={formData.height}
                    onChange={(e) => handleChange("height", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={formData.weight}
                    onChange={(e) => handleChange("weight", e.target.value)}
                  />
                </div>
              </div>

              {stats.bmi > 0 && (
                <div className="mt-4 p-4 bg-blue-50 rounded-md">
                  <h3 className="font-medium text-blue-800">Your Stats</h3>
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <p className="text-sm text-blue-600">BMI</p>
                      <p className="text-lg font-bold">{stats.bmi}</p>
                    </div>
                    {stats.calorieNeeds > 0 && (
                      <div>
                        <p className="text-sm text-blue-600">Daily Calorie Needs</p>
                        <p className="text-lg font-bold">{stats.calorieNeeds} kcal</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="fitness" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="fitnessGoal">Fitness Goal</Label>
                <Select value={formData.fitnessGoal} onValueChange={(value) => handleChange("fitnessGoal", value)}>
                  <SelectTrigger id="fitnessGoal">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lose-weight">Lose Weight</SelectItem>
                    <SelectItem value="build-muscle">Build Muscle</SelectItem>
                    <SelectItem value="improve-fitness">Improve Fitness</SelectItem>
                    <SelectItem value="maintain">Maintain Current Fitness</SelectItem>
                    <SelectItem value="family-activity">Family Activity</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="activityLevel">Activity Level</Label>
                <Select value={formData.activityLevel} onValueChange={(value) => handleChange("activityLevel", value)}>
                  <SelectTrigger id="activityLevel">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                    <SelectItem value="light">Lightly active (light exercise 1-3 days/week)</SelectItem>
                    <SelectItem value="moderate">Moderately active (moderate exercise 3-5 days/week)</SelectItem>
                    <SelectItem value="active">Very active (hard exercise 6-7 days/week)</SelectItem>
                    <SelectItem value="very-active">Extra active (very hard exercise & physical job)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            <TabsContent value="diet" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Dietary Preferences</Label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    "Vegetarian",
                    "Vegan",
                    "Gluten-Free",
                    "Dairy-Free",
                    "Keto",
                    "Paleo",
                    "Low-Carb",
                    "Mediterranean",
                  ].map((preference) => (
                    <div key={preference} className="flex items-center space-x-2">
                      <Checkbox
                        id={preference.toLowerCase()}
                        checked={formData.dietaryPreferences.includes(preference.toLowerCase())}
                        onCheckedChange={() => handleDietaryPreferenceChange(preference.toLowerCase())}
                      />
                      <label
                        htmlFor={preference.toLowerCase()}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {preference}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Allergies or Restrictions</Label>
                <div className="grid grid-cols-2 gap-2">
                  {["Nuts", "Dairy", "Eggs", "Soy", "Wheat", "Shellfish", "Fish"].map((allergy) => (
                    <div key={allergy} className="flex items-center space-x-2">
                      <Checkbox
                        id={`allergy-${allergy.toLowerCase()}`}
                        checked={formData.allergies.includes(allergy.toLowerCase())}
                        onCheckedChange={() => handleAllergyChange(allergy.toLowerCase())}
                      />
                      <label
                        htmlFor={`allergy-${allergy.toLowerCase()}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {allergy}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Saving..." : "Save Changes"}
          </Button>
        </CardFooter>
      </Card>
    </form>
  )
}

