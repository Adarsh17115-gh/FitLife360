"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChartContainer, ChartTooltip } from "@/components/ui/chart"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend } from "recharts"
import { Search, Plus, Camera, Utensils, Clock } from "lucide-react"

const COLORS = ["#4f46e5", "#10b981", "#f59e0b", "#ec4899"]

const macroData = [
  { name: "Protein", value: 120, goal: 140, unit: "g" },
  { name: "Carbs", value: 180, goal: 220, unit: "g" },
  { name: "Fat", value: 65, goal: 70, unit: "g" },
  { name: "Fiber", value: 22, goal: 30, unit: "g" },
]

const mealData = [
  {
    id: 1,
    meal: "Breakfast",
    time: "7:30 AM",
    calories: 420,
    items: [
      { name: "Oatmeal with berries", calories: 280, protein: 12, carbs: 45, fat: 6 },
      { name: "Greek yogurt", calories: 140, protein: 14, carbs: 8, fat: 4 },
    ],
  },
  {
    id: 2,
    meal: "Lunch",
    time: "12:30 PM",
    calories: 650,
    items: [
      { name: "Grilled chicken salad", calories: 450, protein: 35, carbs: 25, fat: 22 },
      { name: "Whole grain bread", calories: 120, protein: 4, carbs: 22, fat: 2 },
      { name: "Apple", calories: 80, protein: 0, carbs: 21, fat: 0 },
    ],
  },
  {
    id: 3,
    meal: "Snack",
    time: "3:30 PM",
    calories: 200,
    items: [
      { name: "Protein shake", calories: 150, protein: 25, carbs: 5, fat: 3 },
      { name: "Banana", calories: 50, protein: 1, carbs: 13, fat: 0 },
    ],
  },
  {
    id: 4,
    meal: "Dinner",
    time: "7:00 PM",
    calories: 570,
    items: [
      { name: "Salmon", calories: 280, protein: 32, carbs: 0, fat: 16 },
      { name: "Brown rice", calories: 150, protein: 3, carbs: 32, fat: 1 },
      { name: "Steamed vegetables", calories: 140, protein: 4, carbs: 28, fat: 1 },
    ],
  },
]

const nutritionData = [
  { name: "Protein", value: 120 },
  { name: "Carbs", value: 180 },
  { name: "Fat", value: 65 },
]

export default function NutritionTracker() {
  const [activeTab, setActiveTab] = useState("today")
  const totalCalories = mealData.reduce((sum, meal) => sum + meal.calories, 0)
  const calorieGoal = 2000
  const caloriesRemaining = calorieGoal - totalCalories

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Nutrition Summary</CardTitle>
                <CardDescription>Track your daily nutrition intake</CardDescription>
              </div>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-[240px]">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="today">Today</TabsTrigger>
                  <TabsTrigger value="week">Week</TabsTrigger>
                  <TabsTrigger value="month">Month</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col justify-center items-center">
                <div className="relative h-[200px] w-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <ChartContainer>
                      <PieChart>
                        <Pie
                          data={nutritionData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}g`}
                        >
                          {nutritionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Legend />
                        <ChartTooltip />
                      </PieChart>
                    </ChartContainer>
                  </ResponsiveContainer>
                </div>
                <div className="text-center mt-4">
                  <h3 className="text-xl font-bold">
                    {totalCalories} / {calorieGoal}
                  </h3>
                  <p className="text-muted-foreground">Calories consumed</p>
                  <p className="text-sm mt-1">
                    <span className={caloriesRemaining > 0 ? "text-green-600" : "text-red-600"}>
                      {caloriesRemaining > 0
                        ? `${caloriesRemaining} calories remaining`
                        : `${Math.abs(caloriesRemaining)} calories over`}
                    </span>
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-4">Macronutrients</h3>
                <div className="space-y-4">
                  {macroData.map((macro, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span className="font-medium">{macro.name}</span>
                        <span>
                          {macro.value} / {macro.goal} {macro.unit}
                        </span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${Math.min(100, (macro.value / macro.goal) * 100)}%`,
                            backgroundColor: COLORS[index % COLORS.length],
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Today's Meals</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Clock className="h-4 w-4 mr-1" /> Schedule
                </Button>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-1" /> Add Meal
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mealData.map((meal) => (
                <div key={meal.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <h3 className="font-medium">{meal.meal}</h3>
                      <p className="text-sm text-muted-foreground">{meal.time}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold">{meal.calories}</span>
                      <span className="text-muted-foreground"> cal</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {meal.items.map((item, index) => (
                      <div key={index} className="flex justify-between text-sm">
                        <span>{item.name}</span>
                        <span className="text-muted-foreground">{item.calories} cal</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Quick Add</CardTitle>
            <CardDescription>Add food to your diary</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search for food..." className="pl-8" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" className="h-auto py-4 flex flex-col">
                  <Camera className="h-5 w-5 mb-1" />
                  <span>Scan Food</span>
                </Button>
                <Button variant="outline" className="h-auto py-4 flex flex-col">
                  <Utensils className="h-5 w-5 mb-1" />
                  <span>My Recipes</span>
                </Button>
              </div>
              <div className="pt-2">
                <h3 className="font-medium mb-3">Recent Foods</h3>
                <div className="space-y-3">
                  {["Greek yogurt", "Grilled chicken", "Protein shake", "Banana", "Oatmeal"].map((food, index) => (
                    <div
                      key={index}
                      className="flex justify-between items-center p-2 hover:bg-gray-50 rounded-md cursor-pointer"
                    >
                      <span>{food}</span>
                      <Plus className="h-4 w-4 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AI Meal Suggestions</CardTitle>
            <CardDescription>Based on your nutrition goals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                <h4 className="font-medium">High-Protein Dinner</h4>
                <p className="text-sm text-muted-foreground">Grilled salmon with quinoa and roasted vegetables</p>
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">520 cal</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">42g protein</span>
                </div>
              </div>
              <div className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                <h4 className="font-medium">Post-Workout Snack</h4>
                <p className="text-sm text-muted-foreground">Protein smoothie with banana and almond butter</p>
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">310 cal</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">24g protein</span>
                </div>
              </div>
              <div className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer">
                <h4 className="font-medium">Family-Friendly Lunch</h4>
                <p className="text-sm text-muted-foreground">Turkey and avocado wraps with side salad</p>
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">420 cal</span>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">28g protein</span>
                </div>
              </div>
              <Button variant="outline" className="w-full mt-2">
                View More Suggestions
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

