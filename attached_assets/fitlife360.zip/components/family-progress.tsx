"use client"

import type React from "react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChartContainer, ChartTooltip, ChartLegend, ChartLegendItem } from "@/components/ui/chart"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { useState } from "react"

const familyMembers = [
  { id: 1, name: "David", role: "Dad", avatar: "D", progress: 92, color: "#4f46e5" },
  { id: 2, name: "Maria", role: "Mom", avatar: "M", progress: 88, color: "#ec4899" },
  { id: 3, name: "Sam", role: "Son", avatar: "S", progress: 75, color: "#10b981" },
  { id: 4, name: "Emma", role: "Daughter", avatar: "E", progress: 82, color: "#f59e0b" },
]

const weeklyData = [
  { day: "Mon", David: 85, Maria: 75, Sam: 60, Emma: 70 },
  { day: "Tue", David: 88, Maria: 80, Sam: 65, Emma: 75 },
  { day: "Wed", David: 90, Maria: 85, Sam: 70, Emma: 78 },
  { day: "Thu", David: 87, Maria: 82, Sam: 68, Emma: 80 },
  { day: "Fri", David: 92, Maria: 88, Sam: 75, Emma: 82 },
  { day: "Sat", David: 95, Maria: 90, Sam: 80, Emma: 85 },
  { day: "Sun", David: 93, Maria: 87, Sam: 78, Emma: 83 },
]

const monthlyData = [
  { week: "Week 1", David: 82, Maria: 72, Sam: 58, Emma: 68 },
  { week: "Week 2", David: 85, Maria: 78, Sam: 62, Emma: 72 },
  { week: "Week 3", David: 90, Maria: 83, Sam: 70, Emma: 78 },
  { week: "Week 4", David: 92, Maria: 88, Sam: 75, Emma: 82 },
]

export default function FamilyProgress() {
  const [timeframe, setTimeframe] = useState("weekly")
  const chartData = timeframe === "weekly" ? weeklyData : monthlyData
  const xAxisKey = timeframe === "weekly" ? "day" : "week"

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Family Progress</CardTitle>
            <CardDescription>Track everyone's fitness journey</CardDescription>
          </div>
          <Tabs value={timeframe} onValueChange={setTimeframe} className="w-[180px]">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-8">
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ChartContainer>
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey={xAxisKey} fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}%`} />
                  <ChartTooltip content={<CustomTooltip />} />
                  {familyMembers.map((member) => (
                    <Area
                      key={member.id}
                      type="monotone"
                      dataKey={member.name}
                      stackId="1"
                      stroke={member.color}
                      fill={member.color}
                      fillOpacity={0.2}
                    />
                  ))}
                </AreaChart>
                <ChartLegend className="flex justify-center mt-2">
                  {familyMembers.map((member) => (
                    <ChartLegendItem key={member.id} className="mx-2" style={{ color: member.color }}>
                      {member.name}
                    </ChartLegendItem>
                  ))}
                </ChartLegend>
              </ChartContainer>
            </ResponsiveContainer>
          </div>

          <div className="space-y-4">
            {familyMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${member.avatar}`} alt={member.name} />
                  <AvatarFallback style={{ backgroundColor: member.color, color: "white" }}>
                    {member.avatar}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <div>
                      <span className="font-medium">{member.name}</span>
                      <span className="text-sm text-muted-foreground ml-2">{member.role}</span>
                    </div>
                    <span className="font-medium">{member.progress}%</span>
                  </div>
                  <Progress
                    value={member.progress}
                    className="h-2"
                    style={
                      {
                        "--progress-background": member.color,
                      } as React.CSSProperties
                    }
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) {
    return null
  }

  return (
    <div className="bg-white p-2 border rounded-md shadow-sm">
      <p className="font-medium">{label}</p>
      {payload.map((entry, index) => (
        <div key={index} className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
          <span style={{ color: entry.color }}>
            {entry.name}: {entry.value}%
          </span>
        </div>
      ))}
    </div>
  )
}

