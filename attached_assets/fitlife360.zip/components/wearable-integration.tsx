"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Activity, Smartphone, Watch } from "lucide-react"

export default function WearableIntegration() {
  const { toast } = useToast()
  const [integrations, setIntegrations] = useState({
    googleFit: false,
    appleHealth: false,
    fitbit: false,
  })
  const [isConnecting, setIsConnecting] = useState(false)

  const handleConnect = async (service) => {
    setIsConnecting(true)

    // This would be replaced with actual OAuth flow in a real implementation
    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setIntegrations((prev) => ({ ...prev, [service]: true }))

      toast({
        title: "Connected Successfully",
        description: `Your ${getServiceName(service)} account has been connected.`,
      })
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: `Failed to connect to ${getServiceName(service)}. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const handleDisconnect = async (service) => {
    setIsConnecting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setIntegrations((prev) => ({ ...prev, [service]: false }))

      toast({
        title: "Disconnected",
        description: `Your ${getServiceName(service)} account has been disconnected.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to disconnect from ${getServiceName(service)}. Please try again.`,
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const getServiceName = (service) => {
    switch (service) {
      case "googleFit":
        return "Google Fit"
      case "appleHealth":
        return "Apple Health"
      case "fitbit":
        return "Fitbit"
      default:
        return service
    }
  }

  const getServiceIcon = (service) => {
    switch (service) {
      case "googleFit":
        return <Activity className="h-5 w-5 text-green-600" />
      case "appleHealth":
        return <Smartphone className="h-5 w-5 text-red-600" />
      case "fitbit":
        return <Watch className="h-5 w-5 text-blue-600" />
      default:
        return <Activity className="h-5 w-5" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Wearable Integrations</CardTitle>
        <CardDescription>Connect your fitness devices and apps to sync your health data</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          {Object.keys(integrations).map((service) => (
            <div key={service} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="bg-gray-100 p-2 rounded-full">{getServiceIcon(service)}</div>
                <div>
                  <h3 className="font-medium">{getServiceName(service)}</h3>
                  <p className="text-sm text-muted-foreground">
                    {integrations[service] ? "Connected" : "Not connected"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={integrations[service]}
                  onCheckedChange={() => {
                    if (integrations[service]) {
                      handleDisconnect(service)
                    } else {
                      handleConnect(service)
                    }
                  }}
                  disabled={isConnecting}
                />
                <Label htmlFor={`${service}-switch`} className="sr-only">
                  {integrations[service] ? "Disconnect" : "Connect"} {getServiceName(service)}
                </Label>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex flex-col items-start">
        <p className="text-sm text-muted-foreground mb-2">
          Connecting your wearable devices allows FitLife 360 to automatically sync your activity, sleep, and other
          health data.
        </p>
        <p className="text-sm text-muted-foreground">
          We only access the data you authorize and your privacy is our priority.
        </p>
      </CardFooter>
    </Card>
  )
}

