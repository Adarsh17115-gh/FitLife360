"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Calendar, Dumbbell, Clock, Play, CheckCircle, Users, ArrowRight, BarChart } from "lucide-react"

const workoutPlans = [
  {
    id: 1,
    title: "Family HIIT Challenge",
    description: "30-minute high-intensity interval training for the whole family",
    level: "All Levels",
    duration: "30 min",
    calories: "250-350",
    category: "Cardio",
    participants: ["D", "M", "S", "E"],
    exercises: [
      { name: "Jumping Jacks", duration: "45 sec", rest: "15 sec" },
      { name: "Squats", duration: "45 sec", rest: "15 sec" },
      { name: "Mountain Climbers", duration: "45 sec", rest: "15 sec" },
      { name: "Push-ups (modified ok)", duration: "45 sec", rest: "15 sec" },
      { name: "Plank", duration: "45 sec", rest: "15 sec" },
      { name: "High Knees", duration: "45 sec", rest: "15 sec" },
      { name: "Lunges", duration: "45 sec", rest: "15 sec" },
      { name: "Burpees", duration: "45 sec", rest: "15 sec" },
    ],
    completed: 0,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    title: "Strength Foundations",
    description: "Build strength with this beginner-friendly resistance workout",
    level: "Beginner",
    duration: "45 min",
    calories: "300-400",
    category: "Strength",
    participants: ["D", "M"],
    exercises: [
      { name: "Dumbbell Squats", sets: "3", reps: "12" },
      { name: "Push-ups", sets: "3", reps: "10" },
      { name: "Dumbbell Rows", sets: "3", reps: "12 each side" },
      { name: "Glute Bridges", sets: "3", reps: "15" },
      { name: "Dumbbell Shoulder Press", sets: "3", reps: "10" },
      { name: "Plank", sets: "3", duration: "30 sec" },
    ],
    completed: 2,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    title: "Kids Fun Fitness",
    description: "Playful exercises designed to keep kids active and engaged",
    level: "Kids",
    duration: "25 min",
    calories: "150-200",
    category: "Play",
    participants: ["S", "E"],
    exercises: [
      { name: "Animal Walks", duration: "3 min" },
      { name: "Freeze Dance", duration: "4 min" },
      { name: "Obstacle Course", duration: "5 min" },
      { name: "Ball Toss Challenge", duration: "4 min" },
      { name: "Hula Hoop Fun", duration: "3 min" },
      { name: "Yoga Poses", duration: "3 min" },
      { name: "Cool Down Stretches", duration: "3 min" },
    ],
    completed: 1,
    image: "/placeholder.svg?height=200&width=300",
  },
]

const weeklySchedule = [
  { day: "Monday", workouts: ["Family HIIT Challenge", "Kids Fun Fitness"] },
  { day: "Tuesday", workouts: ["Strength Foundations"] },
  { day: "Wednesday", workouts: ["Rest Day"] },
  { day: "Thursday", workouts: ["Family HIIT Challenge"] },
  { day: "Friday", workouts: ["Strength Foundations"] },
  { day: "Saturday", workouts: ["Kids Fun Fitness"] },
  { day: "Sunday", workouts: ["Active Recovery - Family Walk"] },
]

export default function WorkoutPlan() {
  const [activeTab, setActiveTab] = useState("workouts")

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="workouts">Workouts</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="workouts" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {workoutPlans.map((workout) => (
              <Card key={workout.id} className="overflow-hidden flex flex-col">
                <div className="relative h-40">
                  <img
                    src={workout.image || "/placeholder.svg"}
                    alt={workout.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-black/70 hover:bg-black/70 text-white">{workout.category}</Badge>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle>{workout.title}</CardTitle>
                  </div>
                  <CardDescription>{workout.description}</CardDescription>
                </CardHeader>
                <CardContent className="pb-2 flex-grow">
                  <div className="grid grid-cols-3 gap-2 mb-4">
                    <div className="flex flex-col items-center p-2 bg-gray-50 rounded-md">
                      <Clock className="h-4 w-4 mb-1 text-muted-foreground" />
                      <span className="text-xs font-medium">{workout.duration}</span>
                    </div>
                    <div className="flex flex-col items-center p-2 bg-gray-50 rounded-md">
                      <BarChart className="h-4 w-4 mb-1 text-muted-foreground" />
                      <span className="text-xs font-medium">{workout.calories}</span>
                    </div>
                    <div className="flex flex-col items-center p-2 bg-gray-50 rounded-md">
                      <Dumbbell className="h-4 w-4 mb-1 text-muted-foreground" />
                      <span className="text-xs font-medium">{workout.level}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground mr-2">Participants:</span>
                    <div className="flex -space-x-2">
                      {workout.participants.map((participant, index) => (
                        <Avatar key={index} className="h-6 w-6 border-2 border-background">
                          <AvatarFallback className="text-xs">{participant}</AvatarFallback>
                        </Avatar>
                      ))}
                    </div>
                  </div>
                  {workout.completed > 0 && (
                    <div className="mt-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{workout.completed}/3 completed</span>
                      </div>
                      <Progress value={workout.completed * 33.33} className="h-2" />
                    </div>
                  )}
                </CardContent>
                <CardFooter>
                  <Button className="w-full">
                    <Play className="h-4 w-4 mr-2" /> Start Workout
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>AI Workout Recommendations</CardTitle>
              <CardDescription>Personalized for your family's fitness goals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">Family Yoga Session</h3>
                      <p className="text-sm text-muted-foreground">Gentle stretching and mindfulness for all ages</p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline">30 min</Badge>
                        <Badge variant="outline">Low Impact</Badge>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">Outdoor Circuit Training</h3>
                      <p className="text-sm text-muted-foreground">Park-based workout using bodyweight exercises</p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline">45 min</Badge>
                        <Badge variant="outline">Moderate</Badge>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  View More Recommendations
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Weekly Schedule</CardTitle>
                  <CardDescription>Your family's workout plan</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Calendar className="h-4 w-4 mr-2" /> Edit Schedule
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weeklySchedule.map((day, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-100 text-blue-800 font-medium rounded-full h-10 w-10 flex items-center justify-center">
                        {day.day.substring(0, 2)}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{day.day}</h3>
                        <div className="mt-2 space-y-2">
                          {day.workouts.map((workout, wIndex) => (
                            <div key={wIndex} className="flex items-center gap-2">
                              {workout === "Rest Day" || workout.includes("Recovery") ? (
                                <Badge variant="outline" className="bg-gray-100">
                                  {workout}
                                </Badge>
                              ) : (
                                <div className="flex items-center justify-between w-full">
                                  <div className="flex items-center gap-2">
                                    <Dumbbell className="h-4 w-4 text-muted-foreground" />
                                    <span>{workout}</span>
                                  </div>
                                  <Button variant="ghost" size="sm">
                                    <ArrowRight className="h-4 w-4" />
                                  </Button>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Workout History</CardTitle>
              <CardDescription>Track your family's progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <h3 className="font-medium">Family HIIT Challenge</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">Completed yesterday</p>
                    </div>
                    <Badge>All Members</Badge>
                  </div>
                  <div className="flex gap-3 mt-3">
                    <div className="text-center">
                      <div className="text-sm font-medium">30</div>
                      <div className="text-xs text-muted-foreground">minutes</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">320</div>
                      <div className="text-xs text-muted-foreground">calories</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">8</div>
                      <div className="text-xs text-muted-foreground">exercises</div>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <h3 className="font-medium">Strength Foundations</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">Completed 2 days ago</p>
                    </div>
                    <Badge>Parents</Badge>
                  </div>
                  <div className="flex gap-3 mt-3">
                    <div className="text-center">
                      <div className="text-sm font-medium">45</div>
                      <div className="text-xs text-muted-foreground">minutes</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">380</div>
                      <div className="text-xs text-muted-foreground">calories</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">6</div>
                      <div className="text-xs text-muted-foreground">exercises</div>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <h3 className="font-medium">Kids Fun Fitness</h3>
                      </div>
                      <p className="text-sm text-muted-foreground">Completed 3 days ago</p>
                    </div>
                    <Badge>Kids</Badge>
                  </div>
                  <div className="flex gap-3 mt-3">
                    <div className="text-center">
                      <div className="text-sm font-medium">25</div>
                      <div className="text-xs text-muted-foreground">minutes</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">180</div>
                      <div className="text-xs text-muted-foreground">calories</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium">7</div>
                      <div className="text-xs text-muted-foreground">exercises</div>
                    </div>
                  </div>
                </div>

                <Button variant="outline" className="w-full">
                  View Complete History
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function Plus({ className }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 5v14M5 12h14" />
    </svg>
  )
}

