"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  MessageSquare,
  Send,
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  Dumbbell,
  Utensils,
  Activity,
  Calendar,
  Clock,
} from "lucide-react"

const initialMessages = [
  {
    id: 1,
    role: "assistant",
    content:
      "Hello Johnson family! I'm your AI Health Coach. How can I help you today with your fitness and nutrition goals?",
    timestamp: "10:30 AM",
  },
]

const recommendations = [
  {
    id: 1,
    title: "Workout Adjustment",
    description: "Based on your recent activity data, I recommend increasing your HIIT sessions to 3x per week.",
    category: "Fitness",
    icon: <Dumbbell className="h-5 w-5 text-blue-500" />,
  },
  {
    id: 2,
    title: "Nutrition Suggestion",
    description: "Your family's protein intake is below target. Consider adding more lean protein sources to dinner.",
    category: "Nutrition",
    icon: <Utensils className="h-5 w-5 text-green-500" />,
  },
  {
    id: 3,
    title: "Sleep Improvement",
    description: "Maria's sleep quality could be improved. Try reducing screen time 1 hour before bed.",
    category: "Health",
    icon: <Activity className="h-5 w-5 text-purple-500" />,
  },
]

const upcomingEvents = [
  {
    id: 1,
    title: "Family HIIT Workout",
    time: "Today, 5:30 PM",
    participants: ["D", "M", "S", "E"],
  },
  {
    id: 2,
    title: "Meal Prep Sunday",
    time: "Sunday, 10:00 AM",
    participants: ["D", "M"],
  },
  {
    id: 3,
    title: "Weekly Health Check",
    time: "Friday, 7:00 PM",
    participants: ["D", "M", "S", "E"],
  },
]

const suggestedQuestions = [
  "How can we improve our family's nutrition?",
  "What exercises are best for kids?",
  "How to balance workouts with a busy schedule?",
  "Tips for staying motivated as a family?",
]

export default function AICoach() {
  const [messages, setMessages] = useState(initialMessages)
  const [inputValue, setInputValue] = useState("")
  const [activeTab, setActiveTab] = useState("chat")

  const handleSendMessage = () => {
    if (inputValue.trim() === "") return

    // Add user message
    const userMessage = {
      id: messages.length + 1,
      role: "user",
      content: inputValue,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, userMessage])
    setInputValue("")

    // Simulate AI response after a short delay
    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        role: "assistant",
        content: getAIResponse(inputValue),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      }

      setMessages((prev) => [...prev, aiResponse])
    }, 1000)
  }

  const getAIResponse = (message) => {
    // Simple response logic based on keywords
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("nutrition") || lowerMessage.includes("food") || lowerMessage.includes("eat")) {
      return "For better family nutrition, I recommend focusing on balanced meals with plenty of vegetables, lean proteins, and whole grains. Based on your family's activity levels, aim for 1800-2200 calories per day for adults and 1400-1800 for children, adjusting based on activity levels. Would you like me to suggest a meal plan for the week?"
    } else if (
      lowerMessage.includes("workout") ||
      lowerMessage.includes("exercise") ||
      lowerMessage.includes("training")
    ) {
      return "For family workouts, I recommend mixing cardio activities like HIIT or family walks with strength training 2-3 times per week. For the kids, focus on fun activities that build fundamental movement skills. Based on your recent workout data, your family is doing well with consistency but could increase intensity slightly. Would you like a specific workout plan?"
    } else if (lowerMessage.includes("kids") || lowerMessage.includes("children")) {
      return "For children's fitness, focus on making it fun and engaging. Activities like obstacle courses, dance parties, and active games are perfect. Sam and Emma have been doing well with their activity levels, but could benefit from more structured movement skills. I've added some kid-friendly exercises to your recommendations tab."
    } else if (lowerMessage.includes("schedule") || lowerMessage.includes("busy") || lowerMessage.includes("time")) {
      return "Balancing fitness with a busy schedule can be challenging. I recommend scheduling workouts like any other important appointment, aiming for 3-4 family activities per week. Short, high-intensity sessions (20-30 minutes) can be very effective. Would you like me to suggest a realistic weekly schedule based on your family calendar?"
    } else {
      return "Thank you for your question. Based on your family's health data and goals, I recommend focusing on consistency with your workouts and balanced nutrition. Your family has been making good progress! Is there a specific area you'd like more detailed guidance on?"
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>AI Health Coach</CardTitle>
                <CardDescription>Your personalized fitness and nutrition assistant</CardDescription>
              </div>
              <TabsList>
                <TabsTrigger value="chat">Chat</TabsTrigger>
                <TabsTrigger value="insights">Insights</TabsTrigger>
              </TabsList>
            </div>
          </CardHeader>

          <TabsContent value="chat" className="m-0">
            <CardContent className="p-0">
              <div className="h-[500px] flex flex-col">
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`}
                    >
                      <div className="flex gap-3 max-w-[80%]">
                        {message.role === "assistant" && (
                          <Avatar className="h-8 w-8">
                            <AvatarImage src="/placeholder.svg?height=32&width=32" />
                            <AvatarFallback className="bg-blue-600 text-white">AI</AvatarFallback>
                          </Avatar>
                        )}
                        <div>
                          <div
                            className={`rounded-lg p-3 ${
                              message.role === "assistant" ? "bg-gray-100 text-gray-900" : "bg-blue-600 text-white"
                            }`}
                          >
                            <p>{message.content}</p>
                          </div>
                          <div className="flex items-center mt-1 text-xs text-muted-foreground">
                            <span>{message.timestamp}</span>
                            {message.role === "assistant" && (
                              <div className="flex items-center ml-2">
                                <Button variant="ghost" size="icon" className="h-6 w-6">
                                  <ThumbsUp className="h-3 w-3" />
                                </Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6">
                                  <ThumbsDown className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        {message.role === "user" && (
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>JF</AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Ask your AI health coach..."
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyDown={handleKeyDown}
                      className="flex-1"
                    />
                    <Button onClick={handleSendMessage}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {suggestedQuestions.map((question, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setInputValue(question)}
                        className="text-xs"
                      >
                        {question}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </TabsContent>

          <TabsContent value="insights" className="m-0">
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-3 flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-amber-500" />
                    Weekly Health Insights
                  </h3>
                  <div className="space-y-3">
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium">Family Progress</h4>
                      <p className="text-sm mt-1">
                        Your family's overall health score has improved by 8% this week. Great job maintaining
                        consistent workouts!
                      </p>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium">Areas for Improvement</h4>
                      <p className="text-sm mt-1">
                        Hydration levels are below target for the children. Try making water more appealing with fruit
                        infusions.
                      </p>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h4 className="font-medium">Sleep Analysis</h4>
                      <p className="text-sm mt-1">
                        Maria's sleep quality has improved since implementing the evening routine. David still shows
                        signs of disrupted sleep patterns.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-3">Personalized Recommendations</h3>
                  <div className="space-y-3">
                    {recommendations.map((rec) => (
                      <div key={rec.id} className="border rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-gray-100 p-2 rounded-full">{rec.icon}</div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{rec.title}</h4>
                              <Badge variant="outline">{rec.category}</Badge>
                            </div>
                            <p className="text-sm mt-1">{rec.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </TabsContent>
        </Tabs>
      </Card>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Coach Features</CardTitle>
            <CardDescription>AI-powered health assistance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 p-2 rounded-full">
                  <MessageSquare className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">Personalized Guidance</h3>
                  <p className="text-sm text-muted-foreground">
                    Get tailored advice based on your family's health data
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-green-100 p-2 rounded-full">
                  <Utensils className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Nutrition Planning</h3>
                  <p className="text-sm text-muted-foreground">Meal suggestions and dietary recommendations</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-purple-100 p-2 rounded-full">
                  <Dumbbell className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium">Workout Optimization</h3>
                  <p className="text-sm text-muted-foreground">Adjusts exercise plans based on progress and goals</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-amber-100 p-2 rounded-full">
                  <Activity className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-medium">Health Insights</h3>
                  <p className="text-sm text-muted-foreground">Analyzes trends and provides actionable insights</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <CardDescription>Scheduled activities and reminders</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{event.title}</h3>
                      <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>{event.time}</span>
                      </div>
                    </div>
                    <div className="flex -space-x-2">
                      {event.participants.map((participant, index) => (
                        <Avatar key={index} className="h-6 w-6 border-2 border-background">
                          <AvatarFallback className="text-xs">{participant}</AvatarFallback>
                        </Avatar>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full">
                <Calendar className="h-4 w-4 mr-2" /> View Full Schedule
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

